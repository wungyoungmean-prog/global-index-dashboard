import { createServer } from 'node:http';
import { readFile } from 'node:fs/promises';

const page = await readFile(new URL('./dist/index.html', import.meta.url));
const apiKey = process.env.MARKET_API_KEY;
const feedConfig = JSON.parse(process.env.MARKET_SYMBOLS || '{}');
const config = new Map(Object.entries(feedConfig));
for (const [index, entry] of config) {
  if (!/^(?:[0-9]|1[0-2])$/.test(index) || !entry?.symbol || !['实时','延迟','收盘'].includes(entry.frequency)) {
    throw new Error('Invalid MARKET_SYMBOLS entry');
  }
}
if (new Set([...config.values()].map(entry => entry.symbol)).size !== config.size) {
  throw new Error('Provider symbols must be unique');
}
const active = !!apiKey && config.size > 0;
const source = 'Twelve Data';
const cache = new Map();
const quotes = new Map();
const streams = new Set();
const periods = new Set(['1D','1W','1M','3M','6M','1Y','3Y','5Y','10Y','20Y','YTD']);
const chinaDay = () => new Intl.DateTimeFormat('sv-SE', {timeZone:'Asia/Shanghai'}).format(new Date());
const validDay = day => /^\d{4}-\d{2}-\d{2}$/.test(day || '') && !Number.isNaN(Date.parse(day)) && new Date(day).toISOString().slice(0,10) === day;
const positive = value => Number.isFinite(Number(value)) && Number(value)>0 ? Number(value) : null;

async function query(path, entry, fields) {
  const url = new URL(path, 'https://api.twelvedata.com');
  url.search = new URLSearchParams({ symbol:entry.symbol, ...(entry.exchange?{exchange:entry.exchange}:{}),...fields });
  const response = await fetch(url, { headers:{Authorization:'apikey '+apiKey}, signal:AbortSignal.timeout(8000) });
  const data = await response.json();
  if (!response.ok || data.status === 'error') throw new Error('upstream');
  return data;
}
async function loadSeries(index, params, ttl) {
  const key = JSON.stringify([index,params]);
  const saved = cache.get(key);
  if (saved && saved.expires > Date.now()) return saved.result;
  if (cache.size >= 180) cache.delete(cache.keys().next().value);
  const result = (async () => {
    try {
      const reply = await query('/time_series', config.get(index), params);
      if (!Array.isArray(reply.values)) throw new Error('upstream');
      return reply.values.map(row => [
        params.interval === '1day' ? row.datetime.slice(0,10) : row.datetime.replace(' ','T')+'Z',positive(row.close)
      ]).filter(([time,value])=>value!==null&&Number.isFinite(Date.parse(time))).sort(([a],[b])=>a.localeCompare(b));
    } catch (error) {
      if(cache.get(key)?.result===result)cache.delete(key);
      throw error;
    }
  })();
  cache.set(key,{expires:Date.now()+ttl,result});
  return result;
}
function startDay(period, latest) {
  const date = new Date(latest+'T12:00:00Z');
  if(period==='YTD')return date.getUTCFullYear()+'-01-01';
  if(period==='1W')date.setUTCDate(date.getUTCDate()-7);
  else {
    const months={'1M':1,'3M':3,'6M':6,'1Y':12,'3Y':36,'5Y':60,'10Y':120,'20Y':240}[period];
    const day=date.getUTCDate();
    date.setUTCDate(1);date.setUTCMonth(date.getUTCMonth()-months);
    const limit=new Date(Date.UTC(date.getUTCFullYear(),date.getUTCMonth()+1,0)).getUTCDate();
    date.setUTCDate(Math.min(day,limit));
  }
  return date.toISOString().slice(0,10);
}
function sendEvent(res, update) {
  if(res.writableLength>64_000){res.end();return}
  res.write('data: '+JSON.stringify(update)+'\n\n');
}
function saveQuote(index, update) {
  const existing=quotes.get(index);
  const quote=existing&&existing.time>update.time ? {...existing,previous:update.previous??existing.previous,marketDay:update.marketDay??existing.marketDay,marketOpen:update.marketOpen??existing.marketOpen} : {...existing,...update};
  quotes.set(index,quote);
  for(const stream of streams)sendEvent(stream,quote);
}
async function refreshQuotes(){
  await Promise.allSettled([...config].map(async ([index,entry])=>{
    const row=await query('/quote',entry,{interval:'1day'});
    const time=Number(row.last_quote_at || row.timestamp)*1000;
    const value=positive(row.close);
    if(value!==null&&time>0&&Number.isFinite(time)){
      saveQuote(index,{index,value,time,previous:positive(row.previous_close),kind:entry.frequency==='收盘'?'收盘':'行情快照',marketDay:String(row.datetime||'').slice(0,10),marketOpen:row.is_market_open});
    }
  }));
}
if(active){
  await refreshQuotes();
  setInterval(refreshQuotes,60_000).unref();
  const realtime = [...config].filter(([,entry])=>entry.frequency==='实时');
  if(realtime.length){
    const indicesBySymbol = new Map(realtime.map(([index,entry])=>[entry.symbol,index]));
    let retry=1000;
    function connect(){
      const addr=new URL('wss://ws.twelvedata.com/v1/quotes/price');
      addr.searchParams.set('apikey',apiKey);
      const socket=new WebSocket(addr);
      let heartbeat;
      const timeout=setTimeout(()=>socket.close(),12_000);
      socket.addEventListener('open',()=>{
        clearTimeout(timeout);
        socket.send(JSON.stringify({action:'subscribe',params:{symbols:realtime.map(([,entry])=>({
          symbol:entry.symbol,...(entry.exchange?{exchange:entry.exchange}:{})
        }))}}));
        heartbeat=setInterval(()=>{
          if(socket.readyState===WebSocket.OPEN)socket.send('{"action":"heartbeat"}');
        },10_000);
      });
      socket.addEventListener('message',event=>{
        let tick;try{tick=JSON.parse(event.data)}catch{return}
        const index=indicesBySymbol.get(tick.symbol),value=positive(tick.price),time=Number(tick.timestamp)*1000;
        if(tick.event==='price'&&index!==undefined&&value!==null&&time>0&&Number.isFinite(time)){
          retry=1000;saveQuote(index,{index,value,time,kind:'实时数据流'});
        }
      });
      socket.addEventListener('close',()=>{
        clearTimeout(timeout);clearInterval(heartbeat);
        setTimeout(connect,retry).unref();retry=Math.min(60_000,retry*2);
      },{once:true});
    }
    connect();
  }
  setInterval(()=>{for(const stream of streams)stream.write(': heartbeat\n\n')},20_000).unref();
}
function json(res,status,payload) {
  res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'});
  res.end(JSON.stringify(payload));
}
const server=createServer(async (req,res)=>{
  if(req.method!=='GET'&&req.method!=='HEAD'){json(res,405,{error:'请求方法不可用。'});return}
  const {pathname,searchParams:params}=new URL(req.url,'http://localhost');
  if(pathname==='/'||pathname==='/index.html'){
    res.writeHead(200,{'Content-Type':'text/html; charset=utf-8','Cache-Control':'no-cache'});
    res.end(req.method==='HEAD'?undefined:page);return;
  }
  if(pathname==='/api/status'){
    json(res,200,{configured:active,source,indices:active?[...config.keys()]:[]});return;
  }
  if(pathname==='/api/quotes'&&active){
    if(req.method==='HEAD'){res.writeHead(200);res.end();return}
    if(streams.size>=300){json(res,503,{error:'行情连接已满，请稍后重试。'});return}
    res.writeHead(200,{'Content-Type':'text/event-stream','Cache-Control':'no-cache, no-transform','X-Accel-Buffering':'no'});
    res.write('retry: 5000\n\n');
    streams.add(res);res.once('close',()=>streams.delete(res));
    for(const quote of quotes.values())sendEvent(res,quote);
    return;
  }
  if(pathname!=='/api/history'&&pathname!=='/api/chart'){
    json(res,404,{error:'没有找到该页面。'});return;
  }
  const index=params.get('index');
  if(!active||!config.has(index)){
    json(res,503,{error:'该指数的在线历史数据暂不可用。可导入历史收盘 CSV 计算。'});return;
  }
  try{
    const today=chinaDay();
    let rows;
    if(pathname==='/api/history'){
      const from=params.get('from'),to=params.get('to');
      if(!validDay(from)||!validDay(to)||from>=to||to>today||Date.parse(to)-Date.parse(from)>3653*86400000){
        json(res,400,{error:'请输入有效的起止日期，在线查询跨度最长 10 年。'});return;
      }
      // Discard the active day's partial candle while the source says the market is open.
      rows=await loadSeries(index,{interval:'1day',start_date:from,end_date:to,outputsize:'5000'},300_000);
      const current=quotes.get(index);
      if(current?.marketOpen!==false){
        const unsettled=current?.marketDay||today;
        rows=rows.filter(([day])=>day<unsettled);
      }
      rows=rows.filter(([day])=>day>=from&&day<=to);
    }else{
      const period=params.get('period');
      if(!periods.has(period)){json(res,400,{error:'无效的图区间。'});return}
      if(period==='1D'){
        rows=await loadSeries(index,{interval:'5min',outputsize:'120',timezone:'UTC'},60_000);
        if(rows.length>1){
          const latest=Date.parse(rows.at(-1)[0]);
          rows=rows.filter(([time])=>latest-Date.parse(time)<12*3600_000);
        }
      }else rows=await loadSeries(index,{interval:'1day',start_date:startDay(period,today),end_date:today,outputsize:'1600'},300_000);
    }
    json(res,200,{source,rows});
  }catch{
    json(res,502,{error:'数据服务暂时无法提供行情，请稍后再试。'});
  }
});
server.listen(Number(process.env.PORT||8080),process.env.BIND_HOST||'0.0.0.0',()=>{
  console.log('Market server listening on '+server.address().port+' (provider configured: '+active+')');
});
